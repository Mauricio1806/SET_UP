"""
Overpass API — busca POIs (Points of Interest) próximos a um ponto.
API pública do OpenStreetMap. Grátis.
"""

import time
from typing import List, Dict
from math import radians, sin, cos, sqrt, atan2
import requests


# Múltiplos endpoints públicos — rotaciona quando um falha
OVERPASS_ENDPOINTS = [
    "https://overpass-api.de/api/interpreter",
    "https://overpass.kumi.systems/api/interpreter",
    "https://maps.mail.ru/osm/tools/overpass/api/interpreter",
]


def haversine_meters(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Distância em metros entre 2 pontos (fórmula haversine)."""
    R = 6371000  # raio da Terra em metros
    phi1, phi2 = radians(lat1), radians(lat2)
    dphi = radians(lat2 - lat1)
    dlambda = radians(lon2 - lon1)
    a = sin(dphi/2)**2 + cos(phi1) * cos(phi2) * sin(dlambda/2)**2
    return 2 * R * atan2(sqrt(a), sqrt(1-a))


class OverpassClient:
    def __init__(self, cache_size=500):
        self._cache: Dict[str, List[Dict]] = {}

    def find_pois(self, lat: float, lon: float, query_tag: str, radius_meters: int = 1000) -> List[Dict]:
        """
        Busca POIs num raio. query_tag exemplo: '["shop"="supermarket"]'
        """
        cache_key = f"{lat:.5f}|{lon:.5f}|{query_tag}|{radius_meters}"
        if cache_key in self._cache:
            return self._cache[cache_key]

        query = f"""
        [out:json][timeout:25];
        (
          node{query_tag}(around:{radius_meters},{lat},{lon});
          way{query_tag}(around:{radius_meters},{lat},{lon});
        );
        out center;
        """

        resp = None
        for endpoint in OVERPASS_ENDPOINTS:
            try:
                time.sleep(1.2)
                resp = requests.post(endpoint, data={"data": query}, timeout=12)
                if resp.status_code == 200:
                    break
                else:
                    print(f"    [overpass] {endpoint[-30:]} → {resp.status_code}, tentando próximo...")
                    resp = None
            except Exception as e:
                print(f"    [overpass] {endpoint[-30:]} → {e.__class__.__name__}, tentando próximo...")
                resp = None

        if not resp:
            print(f"    [overpass] todos endpoints falharam — sem dados de POI")
            return []

        try:
            data = resp.json()
            pois = []
            for element in data.get("elements", []):
                elem_lat = element.get("lat") or element.get("center", {}).get("lat")
                elem_lon = element.get("lon") or element.get("center", {}).get("lon")
                if not elem_lat or not elem_lon:
                    continue
                tags = element.get("tags", {})
                distance = haversine_meters(lat, lon, elem_lat, elem_lon)
                pois.append({
                    "name": tags.get("name", "Sem nome"),
                    "brand": tags.get("brand", ""),
                    "lat": elem_lat,
                    "lon": elem_lon,
                    "distance_meters": round(distance),
                    "walk_minutes": round(distance / 80, 1),
                    "address": self._format_address(tags),
                })
            pois.sort(key=lambda p: p["distance_meters"])
            self._cache[cache_key] = pois
            return pois
        except Exception as e:
            print(f"    [overpass parse erro] {e.__class__.__name__}: {str(e)[:80]}")
            return []

    def _format_address(self, tags: Dict) -> str:
        street = tags.get("addr:street", "")
        housenumber = tags.get("addr:housenumber", "")
        if street and housenumber:
            return f"{street} {housenumber}"
        return street
