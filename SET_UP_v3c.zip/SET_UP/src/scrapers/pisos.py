"""
Pisos.com scraper v3 — seletores amplos + múltiplos paths + filtros.
"""

import re
from typing import List, Dict, Optional
from bs4 import BeautifulSoup
from .base import BaseScraper

INACTIVE_KEYWORDS = [
    'ya no disponible', 'arrendado', 'alquilado', 'reservado',
    'no disponible', 'anuncio eliminado',
]

# Seletores em ordem de especificidade — tenta do mais específico ao mais amplo
CARD_SELECTORS = [
    "div.ad-preview",
    "article.property-listing",
    "article.ad-preview",
    "[class*=ad-preview]",
    "[class*=property-listing]",
    "[class*=PropertyCard]",
    "[class*=property-card]",
    "article[data-ad-id]",
    "article[data-id]",
    "li[data-ad-id]",
    "li[data-id]",
    "article",          # fallback amplo
]


class PisosScraper(BaseScraper):
    BASE_URL = "https://www.pisos.com"

    CITY_PATHS = {
        "granada": [
            "/alquiler/pisos-granada_capital/",
            "/alquiler/pisos-granada/",
        ],
        "alicante": [
            "/alquiler/pisos-alacant_alicante-cap/",
            "/alquiler/pisos-alicante_capital/",
            "/alquiler/pisos-alicante/",
            "/alquiler/pisos-alacant_alicante/",
        ],
        "nerja": [
            "/alquiler/pisos-nerja/",
        ],
    }

    def scrape_city(self, city_key: str, max_price: int = 9999, max_pages: int = 3) -> List[Dict]:
        """max_price=9999 default = sem filtro. Filtro aplicado depois do parse."""
        listings = []
        seen_urls: set = set()
        paths = self.CITY_PATHS.get(city_key, [])
        if not paths:
            return listings

        working_path = None
        working_selector = None
        print(f"  → Pisos.com {city_key}...")

        for candidate in paths:
            test_url = f"{self.BASE_URL}{candidate}"
            html = self.fetch(test_url)
            if not html or len(html) < 3000:
                print(f"    ✗ vazio/bloqueado: {candidate}")
                continue
            if "404" in html[:200] or "página no encontrada" in html.lower()[:500]:
                print(f"    ✗ 404: {candidate}")
                continue

            soup = BeautifulSoup(html, "html.parser")

            # Testa seletores até achar um que retorne cards com preço
            cards, sel_found = [], None
            for sel in CARD_SELECTORS:
                candidates_cards = soup.select(sel)
                # Verifica se pelo menos um tem número de preço
                valid = [c for c in candidates_cards
                         if re.search(r'\d{3,4}\s*[€e]', c.get_text())]
                if valid:
                    cards = candidates_cards
                    sel_found = sel
                    break

            if not cards:
                print(f"    ✗ sem cards com preço: {candidate}")
                # Debug: mostra quantos de cada seletor
                for sel in CARD_SELECTORS[:6]:
                    n = len(soup.select(sel))
                    if n:
                        print(f"      {sel}: {n} (sem preço)")
                continue

            working_path = candidate
            working_selector = sel_found
            print(f"    ✓ path: {candidate} | seletor: {sel_found!r} | {len(cards)} cards")

            for card in cards:
                try:
                    listing = self._parse_listing(card, city_key)
                    if not listing or not listing.get("price"):
                        continue
                    if listing["price"] > max_price:
                        continue
                    if self._is_inactive(listing):
                        continue
                    if listing["url"] in seen_urls:
                        continue
                    seen_urls.add(listing["url"])
                    listings.append(listing)
                except Exception:
                    continue
            break

        if not working_path:
            print(f"    [warn] Nenhum path/seletor funcionou para Pisos.com {city_key}")
            return listings

        for page in range(2, max_pages + 1):
            url = f"{self.BASE_URL}{working_path}?pagina={page}"
            html = self.fetch(url)
            if not html:
                continue
            soup = BeautifulSoup(html, "html.parser")
            cards = soup.select(working_selector) if working_selector else []
            new_in_page = 0
            for card in cards:
                try:
                    listing = self._parse_listing(card, city_key)
                    if not listing or not listing.get("price"):
                        continue
                    if listing["price"] > max_price:
                        continue
                    if self._is_inactive(listing) or listing["url"] in seen_urls:
                        continue
                    seen_urls.add(listing["url"])
                    listings.append(listing)
                    new_in_page += 1
                except Exception:
                    continue
            print(f"    página {page}: {new_in_page} novos")
            if not cards:
                break

        print(f"    ✓ {len(listings)} anúncios Pisos.com ≤ €{max_price}")
        return listings

    def _parse_listing(self, card, city_key: str) -> Optional[Dict]:
        # Título / link — múltiplos seletores
        title_el = (
            card.select_one(".ad-preview__title a") or
            card.select_one("h2 a") or card.select_one("h3 a") or
            card.select_one(".property-title a") or
            card.select_one("[class*=title] a") or
            card.select_one("[class*=Title] a") or
            card.select_one("a[href*='/alquiler/']") or
            card.select_one("a[href*='/piso']") or
            card.select_one("a[href]")
        )
        price_el = (
            card.select_one(".ad-preview__price") or
            card.select_one("[class*=price]") or
            card.select_one("[class*=Price]") or
            card.select_one("[class*=precio]")
        )
        location_el = (
            card.select_one(".ad-preview__subtitle") or
            card.select_one("[class*=location]") or
            card.select_one("[class*=Location]") or
            card.select_one("[class*=address]") or
            card.select_one("[class*=Address]")
        )
        details_el = (
            card.select_one(".ad-preview__char") or
            card.select_one("[class*=char]") or
            card.select_one("[class*=features]") or
            card.select_one("[class*=Features]") or
            card.select_one("[class*=detail]")
        )
        desc_el = (
            card.select_one(".ad-preview__description") or
            card.select_one("[class*=description]") or
            card.select_one("[class*=Description]")
        )

        if not title_el:
            return None

        href = title_el.get("href", "")
        url = href if href.startswith("http") else self.BASE_URL + href
        if not url or url == self.BASE_URL:
            return None

        # Preço — tenta o elemento ou extrai do texto do card
        price = None
        if price_el:
            price = self.parse_price(price_el.get_text())
        if not price:
            # Fallback: extrai primeiro numero 3-4 digitos seguido de €
            m = re.search(r'(\d{3,4})\s*[€]', card.get_text())
            if m:
                price = int(m.group(1))

        details_text = details_el.get_text(" ", strip=True) if details_el else ""
        desc_text = desc_el.get_text(" ", strip=True) if desc_el else ""
        full_text = f"{details_text} {desc_text}".lower()

        location_raw = location_el.get_text(strip=True) if location_el else ""
        location_clean = self._clean_location(location_raw)

        return {
            "source": "pisos.com",
            "city": city_key,
            "title": title_el.get_text(strip=True)[:120],
            "url": url,
            "price": price,
            "location": location_clean[:80],
            "location_raw": location_raw[:100],
            "rooms": self.parse_rooms(details_text),
            "m2": self.parse_m2(details_text),
            "raw_details": full_text[:300],
            "kitchen_type": self._detect_kitchen(full_text),
            "has_cooktop_only": self._detect_kitchen(full_text) == "cooktop_only",
            "is_seasonal": self._is_seasonal(full_text),
        }

    def _clean_location(self, loc: str) -> str:
        if not loc:
            return ""
        parts = [p.strip() for p in re.split(r'[,·|]', loc)]
        filtered = [p for p in parts if p and len(p) > 2
                    and p.lower() not in ('granada', 'alicante', 'nerja', 'spain', 'españa')]
        return (filtered[0] if filtered else parts[0] if parts else loc)[:80]

    def _detect_kitchen(self, text: str) -> str:
        for kw in ['microondas', 'cocina americana', 'sin cocina']:
            if kw in text: return "cooktop_only"
        for kw in ['fogón', 'placa de gas', 'vitrocerámica', 'cocina completa', 'cocina equipada']:
            if kw in text: return "gas_or_full"
        return "unknown"

    def _is_inactive(self, listing: Dict) -> bool:
        text = f"{listing.get('raw_details','')} {listing.get('title','')}".lower()
        return any(kw in text for kw in INACTIVE_KEYWORDS)

    def _is_seasonal(self, text: str) -> bool:
        return any(kw in text for kw in ['temporada', 'vacacional', 'turístico'])
